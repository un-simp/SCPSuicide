﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using Exiled.API.Features;
using Exiled.API.Interfaces;
using HarmonyLib;
using Mirror;
using PlayerStatsSystem;
using SuicidePro.Handlers;
using UnityEngine;

namespace SuicidePro.Configuration
{
	public sealed class Config : IConfig
	{
		public bool IsEnabled { get; set; } = true;
		
		public string CommandPrefix { get; set; } = "kill";

		public string[] CommandAliases { get; set; } = 
		{
			"die",
			"suicide"
		};

		public string[] HelpCommandAliases { get; set; } =
		{
			"help",
			"all",
			"list"
		};

		[Description("If the permission is set to \"default\", it will just be vip.commandname")]
		public List<CommandConfig> KillConfigs { get; set; } = new List<CommandConfig>
		{
			new CommandConfig()
		};

		public bool Debug { get; set; }

		public class CommandConfig
		{
			public string Name { get; set; } = "default";

			public string Description { get; set; } = "The default kill command. Simply kills you.";

			public string Response { get; set; } = "You died.";

			public string Permission { get; set; } = "none";

			public string[] Aliases { get; set; } = Array.Empty<string>();

			public List<RoleType> BannedRoles { get; set; } = new List<RoleType>();

			public CustomDamageHandler DamageHandler { get; set; } = new CustomDamageHandler();
		}

		public class CustomDamageHandler
		{
			public string Reason { get; set; } = "Suicided.";
			public string CassieIfScp { get; set; } = String.Empty;
			public int ForwardVelocity { get; set; }
			public int RightVelocity { get; set; }
			public int UpVelocity { get; set; }
		}
	}
}
