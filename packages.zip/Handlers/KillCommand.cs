﻿using System;
using System.Globalization;
using System.Linq;
using System.Reflection;
using CommandSystem;
using Exiled.API.Features;
using Exiled.Permissions.Extensions;
using GameCore;
using Mirror;
using PlayerStatsSystem;
using RemoteAdmin;
using SuicidePro.Configuration;
using UnityEngine;
using Log = Exiled.API.Features.Log;

namespace SuicidePro.Handlers
{
	[CommandHandler(typeof(ClientCommandHandler))]
	public class KillCommand : ICommand
	{
		public string Command { get; } = Plugin.Instance.Config.CommandPrefix;
		public string[] Aliases { get; } = Plugin.Instance.Config.CommandAliases;
		public string Description { get; } = "A kill command with more features.";

		public bool Execute(ArraySegment<string> arguments, ICommandSender sender, out string response)
		{
			PlayerCommandSender playerCommandSender = sender as PlayerCommandSender;
			if (playerCommandSender == null)
			{
				response = "You must run this command as a client and not server.";
				return false;
			}

			string arg = arguments.FirstOrDefault();
			Player player = Player.Get(playerCommandSender);

			if (Plugin.Instance.Config.HelpCommandAliases.Contains(arg))
			{
				response = "Here are all the kill commands you can use:\n\n";
				foreach (Config.CommandConfig commandConfig in Plugin.Instance.Config.KillConfigs)
				{
					if (commandConfig.Permission == "none" || player.CheckPermission(FormatPermission(commandConfig)))
						response += $"<b><color=white>.{Plugin.Instance.Config.CommandPrefix}</color> <color=yellow>{commandConfig.Name}</color></b> {(commandConfig.Aliases.Any() ? $"<color=#3C3C3C>({String.Join(", ", commandConfig.Aliases)})</color>" : String.Empty)}\n<color=white>{commandConfig.Description}</color>\n\n";
				}
				return true;
			}

			if (arg == null)
				arg = "default";

			Config.CommandConfig config = Plugin.Instance.Config.KillConfigs.FirstOrDefault(x => x.Name == arg || x.Aliases.Contains(arg));

			if (config == null)
			{
				response = $"Could not find any kill command with the name or alias {arg}.";
				return false;
			}

			if (config.Permission != "none" && !player.CheckPermission(FormatPermission(config)))
			{
				response = "You do not have the required permissions for this command.";
				return false;
			}

			if (!Round.IsStarted)
			{
				response = "The round has not started yet.";
				return false;
			}

			if (config.BannedRoles.Contains(player.Role) || player.IsDead)
			{
				response = "You cannot run this kill variation as your role.";
				return false;
			}

			Log.Debug("Dealing damage...", Plugin.Instance.Config.Debug);
			try
			{
				var handler = new CustomReasonDamageHandler(config.DamageHandler.Reason, float.MaxValue, config.DamageHandler.CassieIfScp);
				player.Hurt(handler);
				handler.GetType().GetField("StartVelocity", BindingFlags.NonPublic | BindingFlags.Instance).SetValue(handler, player.ReferenceHub.playerMovementSync.PlayerVelocity + (player.CameraTransform.forward * config.DamageHandler.ForwardVelocity + player.CameraTransform.right * config.DamageHandler.RightVelocity + player.CameraTransform.up * config.DamageHandler.UpVelocity));
			}
			catch (Exception e)
			{
				Log.Error(e);
			}

			Log.Debug("Dealt damage successfully", Plugin.Instance.Config.Debug);
			response = config.Response;
			Log.Debug("Setting response and finished up.", Plugin.Instance.Config.Debug);
			return true;
		}

		public string FormatPermission(Config.CommandConfig config)
		{
			if (config.Permission == "default")
			{
				Log.Debug("Permission name is 'default', returning kl." + config.Name, Plugin.Instance.Config.Debug);
				return $"kl.{config.Name}";
			}
			Log.Debug("Permission name is not 'default', returning " + config.Permission, Plugin.Instance.Config.Debug);
			return config.Permission;
		}
	}
}
