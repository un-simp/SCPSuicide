﻿using System;
using Exiled.API.Features;

namespace SuicidePro
{
    public class Plugin : Plugin<Configuration.Config>
    {
        public override string Author { get; } = "TheUltiOne";
        public override string Name { get; } = "Suicide - Pro Edition";
        public override Version Version { get; } = new Version(0, 1, 0);
        public override Version RequiredExiledVersion { get; } = new Version(4, 0, 0);

        public static Plugin Instance;

        public override void OnEnabled()
        {
            Instance = this;
            base.OnEnabled();
        }
    }
}